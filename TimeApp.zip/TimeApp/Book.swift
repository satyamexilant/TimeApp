//
//  Book.swift
//  TimeApp
//
//  Created by avnish kumar on 01/03/16.
//  Copyright © 2016 medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa

class Book: NSObject
{
    let name:String
    let price:Float
    let author:String
    
    
    init(name:String, price:Float, author:String)
    {
        self.name = name
        self.price = price
        self.author = author
        
        super.init()
    }
}
