//
//  LoginWindow.swift
//  TimeTime
//
//  Created by medidi vv satyanarayana murty on 02/02/16.
//  Copyright © 2016 Medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa
import SecurityFoundation

let Keychain_keyName = "password"
class LoginWindow: NSWindowController
{
    @IBOutlet var userName: NSTextField!
    @IBOutlet var password: NSSecureTextField!
    @IBOutlet var loginButton: NSButton!
    
    let keyChain = KeychainSwift()
    
    let createLoginButtonTag = 0
    let loginButtonTag = 1
    
    var timeSheetLayout:TimeSheetWindow? = nil
    var forgotPassword:ForgotPasswordWindow? = nil
    
    @IBOutlet var outlineView: NSOutlineView!
    
    var timer = NSTimer()
    
    @IBOutlet var textField: NSTextField!
    
    var student1 = Student(name: "avnish", usn: "4jn09IS015", image: NSImage())
    
    var student2 = Student(name: "manish", usn: "4jn09IS018", image: NSImage())
    
    override func windowDidLoad()
    {
        super.windowDidLoad()
        
        if let _ = NSUserDefaults.standardUserDefaults().valueForKey("username")
        {
            loginButton.title = "LogIn"
            loginButton.tag = loginButtonTag
         }
        else
        {
             print(" No user Found ")
             loginButton.title = "Create"
             loginButton.tag = createLoginButtonTag
         }
        
        
        self.timer = NSTimer.scheduledTimerWithTimeInterval(1.0,
            target: self,
            selector: Selector("tick"),
            userInfo: nil,
            repeats: true)
        
       

       
    }
    
    func tick()
    {
        
        let curCalendar = NSCalendar.currentCalendar()
        let dateComponents = curCalendar.components(NSCalendarUnit(rawValue: NSCalendarUnit.Hour.rawValue | NSCalendarUnit.Minute.rawValue | NSCalendarUnit.Second.rawValue), fromDate: NSDate())
        
        self.textField.stringValue = "\(dateComponents.hour):\(dateComponents.minute):\(dateComponents.second)"
    }
    
    override func windowWillLoad() {
        
        setModel()
    }
    
    override var windowNibName:String
    {
        
        return "LoginWindow"
    }
    
    
    func setModel()
    {
        let book1 = Book(name: "math", price: 120.0, author: "A.K.Singh")
        let book2 = Book(name: "Science", price: 145.0, author: "H.C.Varma")
        let book5 = Book(name: "jokes", price: 145.0, author: "H.C.Varma")
        let book6 = Book(name: "comedy", price: 145.0, author: "H.C.Varma")
        
        
        
        student1.books.append(book1)
        student1.books.append(book2)
        student1.books.append(book5)
        student1.books.append(book6)
        
        let book3 = Book(name: "Physics", price: 84.0, author: "C.K.Singh")
        let book4 = Book(name: "Chemistry", price: 98.0, author: "M.Singh")
        
        
        student2.books.append(book3)
        student2.books.append(book4)
        
        
    }
    
    
    @IBAction func resetFields(sender: NSButton)
    {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults()
        defaults.removeObjectForKey("username")
        keyChain.delete(Keychain_keyName)
        password.stringValue = ""
        userName.stringValue = ""
        loginButton.title = "Create"
        loginButton.tag = createLoginButtonTag
        
        outlineView.reloadData()
        
       
    }
    
    @IBAction func forgotPassword(sender: NSButton)
    {
        self.window?.close()
        let fpwc = ForgotPasswordWindow(windowNibName: "ForgotPasswordWindow")
        fpwc.showWindow(self)
        forgotPassword = fpwc
    }
    
    @IBAction func login(sender: NSButton)
    {
        if sender.tag == loginButtonTag
        {
            
            if (userName.stringValue == "" || password.stringValue == "")
            {
                let alert = NSAlert()
                alert.messageText = "Error"
                alert.informativeText = "Password Should Notbe Empty"
                alert.runModal()
                return
            }
            
            if checkLogin(userName.stringValue, password: password.stringValue)
            {
                let alert = NSAlert()
                alert.messageText = "Success"
                alert.informativeText = "Successfully Login"
                alert.runModal()
                password.stringValue = ""
                self.window?.close()
                let ts = TimeSheetWindow(windowNibName: "TimeSheetWindow")
                ts.showWindow(self)
                timeSheetLayout = ts
                
                           }
                
            else
            {
                let alert = NSAlert()
                alert.messageText = "Error"
                alert.informativeText = "Wrong Password "
                password.stringValue = ""
                alert.runModal()
            }
            
            
        }
        else
        {
            if (userName.stringValue == "" || password.stringValue == "")
            {
                let alert = NSAlert()
                alert.messageText = "Error"
                alert.informativeText = " Creation Failed "
                alert.runModal()
                return
            }
            else
            {
                
                let hasKey = NSUserDefaults.standardUserDefaults().boolForKey("hasLoginKey")
                if hasKey == false
                {
                    NSUserDefaults.standardUserDefaults().setObject(userName.stringValue, forKey: "username")
                }
                
                NSUserDefaults.standardUserDefaults().setBool(true, forKey: "hasPassword")
                NSUserDefaults.standardUserDefaults().synchronize()
                
                keyChain.set(password.stringValue, forKey: Keychain_keyName)
                let alert = NSAlert()
                alert.messageText = "Success"
                alert.informativeText = "Successfully Created"
                alert.runModal()
                password.stringValue = ""
                loginButton.title = "Login"
                loginButton.tag = loginButtonTag


            }
        }
    }






    func checkLogin(username: String, password: String ) -> Bool
    {
       if (password == keyChain.get(Keychain_keyName)) && username == (NSUserDefaults.standardUserDefaults().valueForKey("username") as? String)!
       {
          return true
       }
       else
       {
         return false
       }
        
    }
    
    
    
    @IBAction func showTime(sender:NSToolbarItem)
    {
        let alert = NSAlert()
        let date = NSDate()
    
        let curCalendar = NSCalendar.currentCalendar()
        let dateComponents = curCalendar.components(NSCalendarUnit(rawValue: NSCalendarUnit.Hour.rawValue | NSCalendarUnit.Minute.rawValue | NSCalendarUnit.Second.rawValue), fromDate: date)
        
        
        alert.messageText = "\(dateComponents.hour):\(dateComponents.minute):\(dateComponents.second)"
        alert.runModal()
        
    
        
    }
    
    func outlineView(outlineView: NSOutlineView,
        child index: Int,
        ofItem item: AnyObject?) -> AnyObject
    {
        if let item = item
        {
            switch item
            {
                case let student as Student:
                    return student.books[index]
                
                default: return self
            }
            
        }
        else
        {
            switch index
            {
                case 0: return student1
                case 1: return student2
                default: return self
            }
        }
    }
    
    func outlineView(outlineView: NSOutlineView,
        numberOfChildrenOfItem item: AnyObject?) -> Int
    {
        if let item = item
        {
            switch item
            {
                case let student as Student:
                return student.books.count
                
                default: return 0
            }
        }
        else
        {
                return 2
        }
    }
    
    
    func outlineView(outlineView: NSOutlineView,
        isItemExpandable item: AnyObject) -> Bool
    {
            switch item
            {
                case let student as Student:
                    return student.books.count > 0 ? true:false
                
                default: return false
            }
       

    }
    
    func outlineView(outlineView: NSOutlineView, viewForTableColumn: NSTableColumn?, item: AnyObject) -> NSView?
    {
        
            switch item
            {
                case let student as Student:
                    
                    let view = outlineView.makeViewWithIdentifier("HeaderCell", owner: self) as! NSTableCellView
                    view.textField?.stringValue = student.name
                    return view
                
                case let book as Book:
                
                    let view = outlineView.makeViewWithIdentifier("DataCell", owner: self) as! NSTableCellView
                    view.textField?.stringValue = book.name
                return view
                default: return nil
            }
       
    }
    
    func outlineViewSelectionIsChanging(notification: NSNotification)
    {
        let selectedObject = notification.object?.itemAtRow((notification.object?.selectedRow)!)
        
        switch selectedObject
        {
            case let student as Student:
            
                print("\(student.name)")
        case let book as Book:
                print("\(book.name)")
        default: print("Unknown")
            
        }
       
    }
    
    @IBAction func sendMail(sender: NSButton)
    {
        var fileURLs:[NSURL] = []
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.allowedFileTypes = ["png"]
    
        let result = panel.runModal()

        if(result == NSFileHandlingPanelOKButton)
        {
            fileURLs = panel.URLs
        }
        
        
        let service = NSSharingService(named: NSSharingServiceNameComposeEmail)
        service?.subject = "Hello"
        
        

        
        service?.recipients = ["avnish015@gmail.com"]
        
        var attachment = [AnyObject]()
        attachment.append("Hi avnish")
        for i in fileURLs
        {
           attachment.append(i)
        }
        
        
        service?.performWithItems(attachment)
    }
}


