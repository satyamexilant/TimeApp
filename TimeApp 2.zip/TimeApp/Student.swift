//
//  Student.swift
//  TimeApp
//
//  Created by avnish kumar on 01/03/16.
//  Copyright © 2016 medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa

class Student: NSObject
{
    let name:String
    let usn:String
    let image:NSImage
    var books:[Book] = []
    
    
    init(name:String, usn:String, image:NSImage)
    {
        self.name = name
        self.usn = usn
        self.image = image
        super.init()
    }
}
